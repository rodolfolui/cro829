

#
#
# Description: The startup script for Maria DB.
#              It will use all the security keys from vault.
#
#
#
#
#!/bin/sh

# default values
  EAMSROOT=/opt/panaces

FILE_NAME=$EAMSROOT/installconfig/panaces.properties

read -p "Enter Vault Server SSL certificate file: " vault_server_cert
if [ -z "$vault_server_cert" ]; then
    echo "Please enter valid SSL certificate file"
    exit 1	
fi
getKeysFromVault() {
output=$(curl --header "X-Vault-Token: ${vault_server_token}" https://${vault_server_host}:${vault_server_port}${vault_server_api}$2 --cacert ${vault_server_cert} 2>/dev/null)
if [ "$output" == *"errors"*  -o  -z "$output" ]; then
echo "Error while getting the secrets!!...Exiting"
exit 1
else
echo $output | awk -F'[{]' '{print $4}' | awk -F'["]' '{print $4}' | xargs -0 printf "%b" | base64 -d > $1 2>/dev/null
chmod 770 $1
chown panacesuser:panacestomcatgroup $1
fi
}

getProperty()
{
        prop_key=$1
        prop_value=`cat ${FILE_NAME} | grep ${prop_key} | cut -d'=' -f2`
}

vault_server_enabled=""
if [ ! -f "$FILE_NAME" ]; then
vault_server_enabled=true
read -p "Enter Vault Server IP : " vault_server_host
if ! [[ "$vault_server_host" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then  
echo "Please enter valid vault server host IP"
  exit 1	
fi
read -p "Enter Vault Server Port : " vault_server_port
if ! [[ "$vault_server_port" =~ ^[0-9]+$ ]]
    then
        echo "Please enter valid vault server port number"
	exit 1
fi

read -p "Enter Vault Server API path : " vault_server_api
if [ -z "$vault_server_api" ]; then
    echo "Please enter valid vault API path"
    exit 1
fi
read -p "Enter Vault Server API Token : " vault_server_token
if [ -z "$vault_server_token" ]; then
    echo "Please enter valid vault server token"
    exit 1
fi
else
key="panaces.security.endpoint.vault.enabled"
prop_value=""
getProperty ${key}
echo "Key = ${key} ; Value = " ${prop_value}
vault_server_enabled=${prop_value}
key="panaces.security.endpoint.vault.serverip"
getProperty ${key}
#echo "Key = ${key} ; Value = " ${prop_value}
vault_server_host=${prop_value}
if ! [[ "$vault_server_host" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
echo "Please enter valid vault server host IP"
  exit 1
fi

key="panaces.security.endpoint.vault.serverport"
getProperty ${key}
#echo "Key = ${key} ; Value = " ${prop_value}
vault_server_port=${prop_value}
if ! [[ "$vault_server_port" =~ ^[0-9]+$ ]]
    then
        echo "Please enter valid vault server port number"
        exit 1
fi

key="panaces.security.endpoint.vault.api"
getProperty ${key}
#echo "Key = ${key} ; Value = " ${prop_value}
vault_server_api=${prop_value}
if [ -z "$vault_server_api" ]; then
    echo "Please enter valid vault API path"
    exit 1
fi

key="panaces.security.endpoint.vault.auth_token"
getProperty ${key}
#echo "Key = ${key} ; Value = " ${prop_value}
vault_server_token=${prop_value}
if [ -z "$vault_server_token" ]; then
    echo "Please enter valid vault server token"
    exit 1
fi

fi

# check for CA certificates
FILE_MGMT_KEY=$EAMSROOT/installconfig/mariadbencryption/keys.txt
if [ ! -f "$FILE_MGMT_KEY" -a "$vault_server_enabled" == "true" ]; then
	getKeysFromVault ${FILE_MGMT_KEY} "mariadb_enc_key"
fi

# check for CA certificates
SSL_CA_CERT=$EAMSROOT/installconfig/mariadbencryption/ca-cert.pem
if [ ! -f "$SSL_CA_CERT" -a "$vault_server_enabled" == "true" ]; then
	getKeysFromVault ${SSL_CA_CERT} "ssl_ca_cert"
fi

# check for CA certificates
SSL_SER_CERT=$EAMSROOT/installconfig/mariadbencryption/server-cert.pem
if [ ! -f "$SSL_SER_CERT" -a "$vault_server_enabled" == "true" ]; then
	getKeysFromVault ${SSL_SER_CERT} "ssl_ser_cert"
fi

# check for CA certificates
SSL_SER_KEY=$EAMSROOT/installconfig/mariadbencryption/server-key.pem
if [ ! -f "$SSL_SER_KEY" -a "$vault_server_enabled" == "true" ]; then
	getKeysFromVault ${SSL_SER_KEY} "ssl_ser_key"
fi

# check for CA certificates
SSL_CLI_CERT=$EAMSROOT/installconfig/mariadbencryption/client-cert.pem
if [ ! -f "$SSL_CLI_CERT" -a "$vault_server_enabled" == "true" ]; then
	getKeysFromVault ${SSL_CLI_CERT} "ssl_cli_cert"
fi

# check for CA certificates
SSL_CLI_KEY=$EAMSROOT/installconfig/mariadbencryption/client-key.pem
if [ ! -f "$SSL_CLI_KEY" -a "$vault_server_enabled" == "true" ]; then
	getKeysFromVault ${SSL_CLI_KEY} "ssl_cli_key"
fi

# Start Maria DB

echo "Restarting the Mariab DB with Vault Secrects..."

sudo service mysql restart

echo "Initializing the Maria DB file Management Plugin..."
sleep 60

rm -rf $FILE_MGMT_KEY $SSL_CA_CERT $SSL_SER_CERT $SSL_SER_KEY $SSL_CLI_CERT $SSL_CLI_KEY
